# THIS FILE IS GENERATED FROM APPTOOLS SETUP.PY
version = '4.4.0'
full_version = '4.4.0'
git_revision = 'Unknown'
is_released = True

if not is_released:
    version = full_version
