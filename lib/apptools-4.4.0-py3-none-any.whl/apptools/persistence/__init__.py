#------------------------------------------------------------------------------
# Copyright (c) 2004 by Enthought, Inc.
# All rights reserved.
#------------------------------------------------------------------------------
""" Supports flexible pickling and unpickling of the state of a Python object
    to a dictionary. Part of the AppTools project of the Enthought Tool Suite.
"""
