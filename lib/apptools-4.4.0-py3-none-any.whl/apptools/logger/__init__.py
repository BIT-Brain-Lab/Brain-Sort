#-----------------------------------------------------------------------------
#
#  Copyright (c) 2005 by Enthought, Inc.
#  All rights reserved.
#
#-----------------------------------------------------------------------------
""" Convenience functions for creating logging handlers.
    Part of the EnthoughtBase project.
"""
