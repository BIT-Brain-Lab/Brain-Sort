#------------------------------------------------------------------------------
#
#  Define traits useful with Naming.
#
#  Written by: David C. Morrill
#
#  Date: 08/16/2005
#
#  (c) Copyright 2005 by Enthought, Inc.
#
#------------------------------------------------------------------------------

from .naming_traits import NamingInstance
