# THIS FILE IS GENERATED FROM TRAITS SETUP.PY
version = '5.1.0'
full_version = '5.1.0'
git_revision = 'Unknown'
is_released = True

if not is_released:
    version = full_version
