# dummy script for testing python shell and python editor widgets

# simple import
import sys

# set a variable
x = 1
