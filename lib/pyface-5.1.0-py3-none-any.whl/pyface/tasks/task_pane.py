# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
TaskPane = toolkit_object('tasks.task_pane:TaskPane')
