# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
DockPane = toolkit_object('tasks.dock_pane:DockPane')
